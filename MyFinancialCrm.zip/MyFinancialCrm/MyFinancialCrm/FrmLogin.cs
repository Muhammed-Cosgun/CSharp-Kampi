﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyFinancialCrm.Models;

namespace MyFinancialCrm
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        FinancialCrmDbEntities db = new FinancialCrmDbEntities();

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string username = txtUserName.Text;
                string password = txtPassword.Text;

                if(username==db.Users.Where(x => x.UserId.Equals(1)).Select(x => x.Username).FirstOrDefault())
                {
                    if(password == db.Users.Where(x => x.UserId.Equals(1)).Select(x => x.Password).FirstOrDefault())
                    {
                        FrmBanks banks = new FrmBanks();
                        banks.Show();
                        this.Hide();
                    }  
                    else
                    {
                        MessageBox.Show("Hatalı şifre!");
                    }
                }


                else if (username == db.Users.Where(x => x.UserId.Equals(2)).Select(x => x.Username).FirstOrDefault())
                {
                    if (password == db.Users.Where(x => x.UserId.Equals(2)).Select(x => x.Password).FirstOrDefault())
                    {
                        FrmBanks banks = new FrmBanks();
                        banks.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Hatalı şifre!");
                    }
                }

                else
                {
                    MessageBox.Show("Hatalı kullanıcı adı!");
                }
            }

            catch(Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }
    }
}
