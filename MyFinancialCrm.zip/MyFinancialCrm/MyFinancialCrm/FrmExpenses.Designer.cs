﻿namespace MyFinancialCrm
{
    partial class FrmExpenses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.mskSpendDate = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSpendCategory = new System.Windows.Forms.TextBox();
            this.btnUpdateSpend = new System.Windows.Forms.Button();
            this.btnRemoveSpend = new System.Windows.Forms.Button();
            this.btnCreateSpend = new System.Windows.Forms.Button();
            this.btnSpendList = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSpendAmount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSpendTitle = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSpendId = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(84)))), ((int)(((byte)(128)))));
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Controls.Add(this.button15);
            this.panel1.Location = new System.Drawing.Point(2, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(256, 567);
            this.panel1.TabIndex = 15;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(84)))), ((int)(((byte)(128)))));
            this.button4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(28, 434);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(188, 46);
            this.button4.TabIndex = 5;
            this.button4.Text = "Çıkış Yap";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(84)))), ((int)(((byte)(128)))));
            this.button9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(28, 373);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(188, 46);
            this.button9.TabIndex = 4;
            this.button9.Text = "Ayarlar";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(84)))), ((int)(((byte)(128)))));
            this.button10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(28, 315);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(188, 46);
            this.button10.TabIndex = 3;
            this.button10.Text = "Dashboard";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(84)))), ((int)(((byte)(128)))));
            this.button11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(28, 256);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(188, 44);
            this.button11.TabIndex = 3;
            this.button11.Text = "Banka Hareketleri";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(84)))), ((int)(((byte)(128)))));
            this.button12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(28, 199);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(188, 46);
            this.button12.TabIndex = 3;
            this.button12.Text = "Faturalar";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(84)))), ((int)(((byte)(128)))));
            this.button13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(28, 140);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(188, 46);
            this.button13.TabIndex = 2;
            this.button13.Text = "Giderler";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(84)))), ((int)(((byte)(128)))));
            this.button14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(28, 80);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(188, 46);
            this.button14.TabIndex = 1;
            this.button14.Text = "Bankalar";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(84)))), ((int)(((byte)(128)))));
            this.button15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(28, 23);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(188, 46);
            this.button15.TabIndex = 0;
            this.button15.Text = "Kategoriler";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(113)))), ((int)(((byte)(128)))), ((int)(((byte)(147)))));
            this.panel2.Controls.Add(this.mskSpendDate);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.txtSpendCategory);
            this.panel2.Controls.Add(this.btnUpdateSpend);
            this.panel2.Controls.Add(this.btnRemoveSpend);
            this.panel2.Controls.Add(this.btnCreateSpend);
            this.panel2.Controls.Add(this.btnSpendList);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtSpendAmount);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtSpendTitle);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.txtSpendId);
            this.panel2.Location = new System.Drawing.Point(255, -2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(799, 300);
            this.panel2.TabIndex = 16;
            // 
            // mskSpendDate
            // 
            this.mskSpendDate.BackColor = System.Drawing.Color.Khaki;
            this.mskSpendDate.Location = new System.Drawing.Point(193, 171);
            this.mskSpendDate.Mask = "00/00/0000";
            this.mskSpendDate.Name = "mskSpendDate";
            this.mskSpendDate.Size = new System.Drawing.Size(203, 36);
            this.mskSpendDate.TabIndex = 14;
            this.mskSpendDate.ValidatingType = typeof(System.DateTime);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(12, 224);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(175, 24);
            this.label5.TabIndex = 13;
            this.label5.Text = "Harcama Kategorisi:";
            // 
            // txtSpendCategory
            // 
            this.txtSpendCategory.BackColor = System.Drawing.Color.Khaki;
            this.txtSpendCategory.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSpendCategory.Location = new System.Drawing.Point(193, 221);
            this.txtSpendCategory.Name = "txtSpendCategory";
            this.txtSpendCategory.Size = new System.Drawing.Size(203, 32);
            this.txtSpendCategory.TabIndex = 12;
            // 
            // btnUpdateSpend
            // 
            this.btnUpdateSpend.BackColor = System.Drawing.Color.Silver;
            this.btnUpdateSpend.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnUpdateSpend.ForeColor = System.Drawing.Color.Black;
            this.btnUpdateSpend.Location = new System.Drawing.Point(425, 154);
            this.btnUpdateSpend.Name = "btnUpdateSpend";
            this.btnUpdateSpend.Size = new System.Drawing.Size(169, 46);
            this.btnUpdateSpend.TabIndex = 8;
            this.btnUpdateSpend.Text = "Ödeme Güncelle";
            this.btnUpdateSpend.UseVisualStyleBackColor = false;
            this.btnUpdateSpend.Click += new System.EventHandler(this.btnUpdateSpend_Click);
            // 
            // btnRemoveSpend
            // 
            this.btnRemoveSpend.BackColor = System.Drawing.Color.Silver;
            this.btnRemoveSpend.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRemoveSpend.ForeColor = System.Drawing.Color.Black;
            this.btnRemoveSpend.Location = new System.Drawing.Point(600, 154);
            this.btnRemoveSpend.Name = "btnRemoveSpend";
            this.btnRemoveSpend.Size = new System.Drawing.Size(169, 46);
            this.btnRemoveSpend.TabIndex = 9;
            this.btnRemoveSpend.Text = "Ödeme Sil";
            this.btnRemoveSpend.UseVisualStyleBackColor = false;
            this.btnRemoveSpend.Click += new System.EventHandler(this.btnRemoveSpend_Click);
            // 
            // btnCreateSpend
            // 
            this.btnCreateSpend.BackColor = System.Drawing.Color.Silver;
            this.btnCreateSpend.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCreateSpend.ForeColor = System.Drawing.Color.Black;
            this.btnCreateSpend.Location = new System.Drawing.Point(600, 67);
            this.btnCreateSpend.Name = "btnCreateSpend";
            this.btnCreateSpend.Size = new System.Drawing.Size(169, 46);
            this.btnCreateSpend.TabIndex = 11;
            this.btnCreateSpend.Text = "Yeni Ödeme";
            this.btnCreateSpend.UseVisualStyleBackColor = false;
            this.btnCreateSpend.Click += new System.EventHandler(this.btnCreateSpend_Click);
            // 
            // btnSpendList
            // 
            this.btnSpendList.BackColor = System.Drawing.Color.Silver;
            this.btnSpendList.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSpendList.ForeColor = System.Drawing.Color.Black;
            this.btnSpendList.Location = new System.Drawing.Point(425, 67);
            this.btnSpendList.Name = "btnSpendList";
            this.btnSpendList.Size = new System.Drawing.Size(169, 46);
            this.btnSpendList.TabIndex = 10;
            this.btnSpendList.Text = "Ödeme Listesi";
            this.btnSpendList.UseVisualStyleBackColor = false;
            this.btnSpendList.Click += new System.EventHandler(this.btnSpendList_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(48, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 24);
            this.label4.TabIndex = 7;
            this.label4.Text = "Harcama Tarihi:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(34, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 24);
            this.label3.TabIndex = 5;
            this.label3.Text = "Harcama Miktarı:";
            // 
            // txtSpendAmount
            // 
            this.txtSpendAmount.BackColor = System.Drawing.Color.Khaki;
            this.txtSpendAmount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSpendAmount.Location = new System.Drawing.Point(193, 128);
            this.txtSpendAmount.Name = "txtSpendAmount";
            this.txtSpendAmount.Size = new System.Drawing.Size(203, 32);
            this.txtSpendAmount.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(41, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "Harcama Başlığı:";
            // 
            // txtSpendTitle
            // 
            this.txtSpendTitle.BackColor = System.Drawing.Color.Khaki;
            this.txtSpendTitle.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSpendTitle.Location = new System.Drawing.Point(193, 78);
            this.txtSpendTitle.Name = "txtSpendTitle";
            this.txtSpendTitle.Size = new System.Drawing.Size(203, 32);
            this.txtSpendTitle.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(78, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Harcama Id:";
            // 
            // txtSpendId
            // 
            this.txtSpendId.BackColor = System.Drawing.Color.Khaki;
            this.txtSpendId.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSpendId.Location = new System.Drawing.Point(193, 30);
            this.txtSpendId.Name = "txtSpendId";
            this.txtSpendId.Size = new System.Drawing.Size(203, 32);
            this.txtSpendId.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dataGridView1);
            this.panel3.Location = new System.Drawing.Point(255, 295);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(818, 270);
            this.panel3.TabIndex = 17;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(818, 270);
            this.dataGridView1.TabIndex = 0;
            // 
            // FrmExpenses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1053, 554);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmExpenses";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmExpenses";
            this.Load += new System.EventHandler(this.FrmExpenses_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnUpdateSpend;
        private System.Windows.Forms.Button btnRemoveSpend;
        private System.Windows.Forms.Button btnCreateSpend;
        private System.Windows.Forms.Button btnSpendList;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSpendAmount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSpendTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSpendId;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSpendCategory;
        private System.Windows.Forms.MaskedTextBox mskSpendDate;
    }
}