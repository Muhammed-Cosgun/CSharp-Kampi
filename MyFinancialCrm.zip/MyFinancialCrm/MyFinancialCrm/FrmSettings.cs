﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyFinancialCrm.Models;

namespace MyFinancialCrm
{
    public partial class FrmSettings : Form
    {
        public FrmSettings()
        {
            InitializeComponent();
        }

        FinancialCrmDbEntities db = new FinancialCrmDbEntities();
        private void FrmSettings_Load(object sender, EventArgs e)
        {
            var values = db.Users.ToList();
            dataGridView1.DataSource = values;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int userId = int.Parse(txtUserID.Text);
            string userName = txtUserName.Text;
            string password = txtUserPassword.Text;

            Users users = new Users();
            users.UserId = userId;
            users.Username = userName;
            users.Password = password;
            db.Users.Add(users);
            db.SaveChanges();
            MessageBox.Show("Kullanıcı Başarıyla Eklendi!");

            var values = db.Users.ToList();
            dataGridView1.DataSource = values;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int userId = int.Parse(txtUserID.Text);
            var updatedValues = db.Users.Find(userId);

            string userName = txtUserName.Text;
            string password = txtUserPassword.Text;

            updatedValues.UserId = userId;
            updatedValues.Username = userName;
            updatedValues.Password = password;
            db.SaveChanges();
            MessageBox.Show("Kullanıcı Başarıyla Güncellendi!");

            var values = db.Users.ToList();
            dataGridView1.DataSource = values;
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            int userId = int.Parse(txtUserID.Text);
            var removedValues = db.Users.Find(userId);
            db.Users.Remove(removedValues);
            db.SaveChanges();

            MessageBox.Show("Kullanıcı Başarıyla Silindi!");

            var values = db.Users.ToList();
            dataGridView1.DataSource = values;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmCategories frmCategories = new FrmCategories();
            frmCategories.Show();
            this.Hide();
        }

        private void btnBankForms_Click(object sender, EventArgs e)
        {
            FrmBanks frmBanks = new FrmBanks();
            frmBanks.Show();
            this.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmExpenses frm = new FrmExpenses();
            frm.Show();
            this.Hide();    
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FrmmBilling frmmBilling = new FrmmBilling();
            frmmBilling.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FrmBankProcesses frmBankProcesses = new FrmBankProcesses();
            frmBankProcesses.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FrmDashboard frmDashboard = new FrmDashboard();
            frmDashboard.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }
    }
}
