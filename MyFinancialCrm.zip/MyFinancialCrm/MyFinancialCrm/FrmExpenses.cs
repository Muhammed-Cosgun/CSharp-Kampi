﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyFinancialCrm.Models;

namespace MyFinancialCrm
{
    public partial class FrmExpenses : Form
    {
        public FrmExpenses()
        {
            InitializeComponent();
        }

        FinancialCrmDbEntities db = new FinancialCrmDbEntities();

        private void FrmExpenses_Load(object sender, EventArgs e)
        {
            var values = db.Spendings.ToList();
            dataGridView1.DataSource = values;
        }

        private void btnSpendList_Click(object sender, EventArgs e)
        {
            var values = db.Spendings.ToList();
            dataGridView1.DataSource = values;
        }

        private void btnCreateSpend_Click(object sender, EventArgs e)
        {
            int spendingId = int.Parse(txtSpendId.Text);
            string spendingTitle = txtSpendTitle.Text;
            decimal spendingAmount = decimal.Parse(txtSpendAmount.Text);
            DateTime spendingDate = DateTime.Parse(mskSpendDate.Text);
            int spendingCategory = int.Parse(txtSpendCategory.Text);

            Spendings spendings = new Spendings();
            spendings.SpendingId = spendingId;
            spendings.SpendingTitle = spendingTitle;
            spendings.SpendingAmount = spendingAmount;
            spendings.SpendingDate = spendingDate;
            spendings.CategoryId = spendingCategory;

            db.Spendings.Add(spendings);
            db.SaveChanges();

            MessageBox.Show("Harcama Başarıyla Eklendi!");

            var values = db.Spendings.ToList();
            dataGridView1.DataSource = values;
        }

        private void btnUpdateSpend_Click(object sender, EventArgs e)
        {
            int spendingId = int.Parse(txtSpendId.Text);

            var updatedValues = db.Spendings.Find(spendingId);

            string spendingTitle = txtSpendTitle.Text;
            decimal spendingAmount = decimal.Parse(txtSpendAmount.Text);
            DateTime spendingDate = DateTime.Parse(mskSpendDate.Text);
            int spendingCategory = int.Parse(txtSpendCategory.Text);

            updatedValues.SpendingId = spendingId;
            updatedValues.SpendingTitle = spendingTitle;
            updatedValues.SpendingAmount = spendingAmount;
            updatedValues.SpendingDate = spendingDate;
            updatedValues.CategoryId = spendingCategory;
            db.SaveChanges();

            MessageBox.Show("Harcama Başarıyla Güncellendi!");

            var values = db.Spendings.ToList();
            dataGridView1.DataSource = values;

        }

        private void btnRemoveSpend_Click(object sender, EventArgs e)
        {
            int spendingId = int.Parse(txtSpendId.Text);
            var removedValues = db.Spendings.Find(spendingId);
            db.Spendings.Remove(removedValues);
            db.SaveChanges();
            MessageBox.Show("Harcama Başarıyla Silindi!");
            var values = db.Spendings.ToList();
            dataGridView1.DataSource = values;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            FrmCategories frmCategories = new FrmCategories();
            frmCategories.Show();
            this.Hide();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            FrmBanks frmBanks = new FrmBanks();
            frmBanks.Show();
            this.Hide();
        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            FrmmBilling frmmBilling = new FrmmBilling();
            frmmBilling.Show();
            this.Hide();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            FrmBankProcesses frmBankProcesses = new FrmBankProcesses(); 
            frmBankProcesses.Show();
            this.Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            FrmDashboard frmDashboard = new FrmDashboard();
            frmDashboard.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void button9_Click(object sender, EventArgs e)
        {
            FrmSettings frmSettings = new FrmSettings();
            frmSettings.Show();
            this.Hide();
        }
    }
}
