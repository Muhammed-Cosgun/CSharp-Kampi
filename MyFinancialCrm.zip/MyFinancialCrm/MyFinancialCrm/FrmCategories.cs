﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyFinancialCrm.Models;

namespace MyFinancialCrm
{
    public partial class FrmCategories : Form
    {
        public FrmCategories()
        {
            InitializeComponent();
        }


        FinancialCrmDbEntities db = new FinancialCrmDbEntities();
        private void FrmCategories_Load(object sender, EventArgs e)
        {
            var values = db.Categories.ToList();
            dataGridView1.DataSource = values;
        }

        private void btnList_Click(object sender, EventArgs e)
        {
            var values = db.Categories.ToList();
            dataGridView1.DataSource = values;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int categoryId = int.Parse(txtCategoryId.Text);
            string categoryName = txtCategoryName.Text;

            Categories categories = new Categories();
            categories.CategoryId = categoryId;
            categories.CategoryName = categoryName;

            db.Categories.Add(categories);
            db.SaveChanges();
            MessageBox.Show("Kategori Başarıyla Eklendi!");

            var values = db.Categories.ToList();
            dataGridView1.DataSource = values;
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            int categoryId = int.Parse(txtCategoryId.Text);
            var removeValues = db.Categories.Find(categoryId);
            db.Categories.Remove(removeValues);
            db.SaveChanges();
            MessageBox.Show("Kategori Başarıyla Silindi!");

            var values = db.Categories.ToList();
            dataGridView1.DataSource = values;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int categoryID = int.Parse(txtCategoryId.Text);
            string categoryName = txtCategoryName.Text;

            var updateValue = db.Categories.Find(categoryID);
            updateValue.CategoryName = categoryName;
            db.SaveChanges();
            MessageBox.Show("Kategori Başarıyla Güncellendi!");

            var values = db.Categories.ToList();
            dataGridView1.DataSource = values;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FrmBanks frmBanks = new FrmBanks();
            frmBanks.ShowDialog();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FrmDashboard frmDashboard = new FrmDashboard();
            frmDashboard.ShowDialog();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FrmExpenses frm = new FrmExpenses();
            frm.Show();
            this.Hide();
        }

        private void btnBillform_Click(object sender, EventArgs e)
        {
            FrmmBilling frmmBilling = new FrmmBilling();
            frmmBilling.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FrmBankProcesses frmBankProcesses = new FrmBankProcesses();
            frmBankProcesses.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            FrmSettings frmSettings = new FrmSettings();
            frmSettings.Show();
            this.Hide();
        }
    }
}
