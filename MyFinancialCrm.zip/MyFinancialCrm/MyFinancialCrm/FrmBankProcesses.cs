﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyFinancialCrm.Models;

namespace MyFinancialCrm
{
    public partial class FrmBankProcesses : Form
    {
        public FrmBankProcesses()
        {
            InitializeComponent();
        }

        FinancialCrmDbEntities db = new FinancialCrmDbEntities();
        private void FrmBankProcesses_Load(object sender, EventArgs e)
        {
            var values = db.BankProcesses.ToList();
            dataGridView1.DataSource = values;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var values = db.BankProcesses.ToList();
            dataGridView1.DataSource = values;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int processId = int.Parse(txtProcessId.Text);
            string processDescription = txtProcessDecription.Text;
            DateTime processDate = DateTime.Parse(mskProcessDate.Text);
            string processType = txtProcessType.Text;
            decimal processAmount = decimal.Parse(txtProcessAmount.Text);
            int bankId = int.Parse(txtBankId.Text);

            BankProcesses bankProcesses = new BankProcesses();
            bankProcesses.BankProcessId = processId;
            bankProcesses.BankId = bankId;
            bankProcesses.Decription = processDescription;
            bankProcesses.ProcessDate = processDate;
            bankProcesses.ProcessType = processType;
            bankProcesses.Amount = processAmount;

            db.BankProcesses.Add(bankProcesses);
            db.SaveChanges();
            MessageBox.Show("Banka işlemi başarıyla eklendi!");

            var values = db.BankProcesses.ToList();
            dataGridView1.DataSource = values;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtProcessId.Text);
            var removeValue = db.BankProcesses.Find(id);
            db.BankProcesses.Remove(removeValue);
            db.SaveChanges();
            MessageBox.Show("Banka İşlemi Başarıyla Silindi!");
            var values = db.BankProcesses.ToList();
            dataGridView1.DataSource = values;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtProcessId.Text);
            var updatedValue = db.BankProcesses.Find(id);

            string processDescription = txtProcessDecription.Text;
            DateTime processDate = DateTime.Parse(mskProcessDate.Text);
            string processType = txtProcessType.Text;
            decimal processAmount = decimal.Parse(txtProcessAmount.Text);
            int bankId = int.Parse(txtBankId.Text);
          
            updatedValue.BankProcessId = id;
            updatedValue.BankId = bankId;
            updatedValue.Decription = processDescription;
            updatedValue.ProcessDate = processDate;
            updatedValue.ProcessType = processType;
            updatedValue.Amount = processAmount;

            db.SaveChanges();
            MessageBox.Show("Banka işlemi başarıyla güncellendi!");

            var values = db.BankProcesses.ToList();
            dataGridView1.DataSource = values;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            FrmCategories frmCategories = new FrmCategories();
            frmCategories.Show();
            this.Hide();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            FrmBanks frmBanks = new FrmBanks();
            frmBanks.Show();
            this.Hide();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            FrmmBilling frm = new FrmmBilling();
            frm.Show();
            this.Hide();
        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            FrmDashboard frm = new FrmDashboard();
            frm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            FrmExpenses frm = new FrmExpenses();
            frm.Show();
            this.Hide();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            FrmSettings frmSettings = new FrmSettings();
            frmSettings.Show();
            this.Hide();
        }
    }
}
